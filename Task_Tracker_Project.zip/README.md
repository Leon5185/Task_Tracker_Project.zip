# Task Tracker

## Опис
Це простий веб-додаток для відстеження задач, створений за допомогою Python і Flask.

## Інструкція з встановлення
1. Клонувати репозиторій:
   ```
   git clone https://github.com/yourusername/task-tracker.git
   ```
2. Перейти в директорію проєкту:
   ```
   cd task-tracker
   ```
3. Встановити залежності:
   ```
   pip install -r requirements.txt
   ```
4. Запустити додаток:
   ```
   python app.py
   ```

## Функціонал
- Додавання задач.
- Видалення задач.
